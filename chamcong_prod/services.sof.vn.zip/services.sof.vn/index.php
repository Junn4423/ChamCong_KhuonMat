﻿<?php
 error_reporting(E_ERROR);
 ini_set('display_errors', 1);
 ini_set('display_startup_errors', 1);
//error_reporting(E_ERROR);
//ini_set('display_errors', '0');

// Cho phép từ mọi origin (hoặc cụ thể origin nếu muốn)
header("Access-Control-Allow-Origin: *");

// Cho phép các phương thức
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");

// Cho phép các header custom (như Content-Type)
header("Access-Control-Allow-Headers: Content-Type, Authorization, SOF-User-Token, X-SOF-USER-TOKEN, X-USER-TOKEN, X-USER-CODE, X-USER-USERNAME, X-DATABASE, X-SERVER-IP, X-SERVER-PORT, X-SERVER-USER, X-SERVER-PASSWORD");


// Nếu là request OPTIONS (preflight), trả về sớm
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
	http_response_code(200);
	exit();
}
session_start();

$role = isset($_SERVER['HTTP_ROLE']) ? $_SERVER['HTTP_ROLE'] : '';
$username = isset($_SERVER['HTTP_USERNAME']) ? $_SERVER['HTTP_USERNAME'] : '';
// // ===== BẢO MẬT API =====
// // Kiểm tra SOF User Token
// $userToken = $_SERVER['HTTP_SOF_USER_TOKEN'] ?? $input['token'] ?? $_POST['token'] ?? '';
// $validToken = 'SOF2025DEVELOPER';

// // Kiểm tra token
// if ($userToken !== $validToken) {
//     http_response_code(401);
//     echo json_encode([
//         'error' => 'Unauthorized',
//         'message' => 'Invalid or missing SOF-User-Token'
//     ]);
//     exit;
// }
// // ===== END BẢO MẬT =====


header("Content-Type: application/json; charset=UTF-8");
include("config.php");
include("function.php");
include("lv_controler.php");


$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, true);
// Đảm bảo $input luôn là mảng để tránh cảnh báo undefined index
if (!is_array($input)) {
	$input = [];
}

// ===== QUAN TRỌNG: XỬ LÝ AUTH TRƯỚC =====
// Check nếu là request authentication (login/register)
if (isset($input['method']) || isset($_POST['method'])) {
	if (file_exists("register_user.php")) {
		include("register_user.php");
		exit();
	}

	http_response_code(501);
	echo json_encode([
		'success' => false,
		'message' => 'Auth gateway chua duoc copy vao chamcong/services.sof.vn',
		'errorType' => 'not_implemented'
	]);
	exit();
}

$vtable = $input['table'] ?? ($_POST['table'] ?? null);
$vfun = $input['func'] ?? ($_POST['func'] ?? null);

// Nếu thiếu table/func thì trả về lỗi rõ ràng và kết thúc sớm
if (empty($vtable) || empty($vfun)) {
	http_response_code(400);
	echo json_encode([
		'success' => false,
		'message' => 'Thiếu tham số table hoặc func',
		'errorType' => 'bad_request'
	]);
	exit();
}
$vlimit = isset($input['limit']) ? $input['limit'] : (isset($_POST['limit']) ? $_POST['limit'] : "");
$vmonth = isset($input['month']) ? $input['month'] : (isset($_POST['month']) ? $_POST['month'] : "");
$vyear = isset($input['year']) ? $input['year'] : (isset($_POST['year']) ? $_POST['year'] : "");


$vOutput = array();

function saveImageToDB($fileData, $cot, $lv001)
{
	try {
		$cot = trim((string)$cot);
		if (!preg_match('/^lv[0-9]{3}$/', $cot)) {
			throw new Exception("Tên cột không hợp lệ");
		}

		$docsTable = function_exists('lv_docs_table_name') ? lv_docs_table_name('cr_lv0382') : '`cr_lv0382`';
		if ($docsTable === '') {
			throw new Exception("Không xác định được bảng tài liệu ảnh");
		}

		// Kết nối đến CSDL
		$db = db_connect();
		if (!$db) {
			throw new Exception("Lỗi kết nối CSDL");
		}
		// Kiểm tra xem lv002 = $lv001 đã tồn tại chưa
		$checkSql = "SELECT COUNT(*) as count FROM {$docsTable} WHERE lv002 = ?";

		$checkStmt = mysqli_prepare($db, $checkSql);
		mysqli_stmt_bind_param($checkStmt, "s", $lv001);
		mysqli_stmt_execute($checkStmt);
		$result = mysqli_stmt_get_result($checkStmt);
		$row = mysqli_fetch_assoc($result);
		$exists = $row['count'] > 0;
		mysqli_stmt_close($checkStmt);


		if ($exists) {
			$sql = "UPDATE {$docsTable} SET {$cot} = ? WHERE lv002 = ?";
		} else {
			$sql = "INSERT INTO {$docsTable} (lv002, {$cot}) VALUES (?, ?)";
		}

		$stmt = mysqli_prepare($db, $sql);

		if (!$stmt) {
			throw new Exception("Lỗi chuẩn bị truy vấn: " . mysqli_error($db));
		}


		$null = NULL;

		if ($exists) {
			// Gắn tham số: "sb" = string ($lv001), blob ($fileData)
			mysqli_stmt_bind_param($stmt, "bs", $null, $lv001);
			mysqli_stmt_send_long_data($stmt, 0, $fileData);
		} else {
			mysqli_stmt_bind_param($stmt, "sb", $lv001, $null);
			mysqli_stmt_send_long_data($stmt, 1, $fileData);
		}

		// Thực thi truy vấn
		if (!mysqli_stmt_execute($stmt)) {
			throw new Exception("Lỗi thực thi truy vấn: " . mysqli_stmt_error($stmt));
		}

		// Đóng kết nối
		mysqli_stmt_close($stmt);
		mysqli_close($db);

		return [
			'success' => true,
			'message' => 'Lưu ảnh vào CSDL thành công.',
		];
	} catch (Exception $e) {
		return [
			'success' => false,
			'message' => $e->getMessage(),
		];
	}
}
switch ($vtable) {
	case "hr_lv0020":
		include_once("./class/hr_lv0020.php");
		$hr_lv0020 = new hr_lv0020($_SESSION['ERPSOFV2RRight'], $_SESSION['ERPSOFV2RUserID'], 'Tc0002');

		switch ($vfun) {
			case "data":
				$vOutput = $hr_lv0020->getNhanVien();
				break;

			case "updateImageToken":
				$lv001 = $input['lv001'] ?? $_POST['lv001'] ?? "";
				$tokenAnh = $input['tokenAnh'] ?? $_POST['tokenAnh'] ?? "";
				$cot = $input['cot'] ?? $_POST['cot'] ?? "lv007";

				$lv001 = trim((string)$lv001);
				$tokenAnh = trim((string)$tokenAnh);
				$cot = trim((string)$cot);

				if ($lv001 === "") {
					$vOutput = array('success' => false, 'message' => 'Thiếu mã nhân viên');
					break;
				}
				if ($tokenAnh === "") {
					$vOutput = array('success' => false, 'message' => 'Thiếu token ảnh');
					break;
				}
				if (!preg_match('/^lv[0-9]{3}$/', $cot)) {
					$vOutput = array('success' => false, 'message' => 'Tên cột không hợp lệ');
					break;
				}

				$db = db_connect();
				if (!$db) {
					$vOutput = array('success' => false, 'message' => 'Không kết nối được cơ sở dữ liệu');
					break;
				}

				$lv001Esc = mysqli_real_escape_string($db, $lv001);
				$tokenEsc = mysqli_real_escape_string($db, $tokenAnh);
				$sql = "UPDATE hr_lv0020 SET {$cot}='{$tokenEsc}' WHERE lv001='{$lv001Esc}'";
				$result = db_query($sql);
				if (!$result) {
					$vOutput = array('success' => false, 'message' => 'Lỗi cập nhật token ảnh: ' . sof_error());
					break;
				}

				$affectedRows = mysqli_affected_rows($db);
				if ($affectedRows <= 0) {
					$checkSql = "SELECT lv001 FROM hr_lv0020 WHERE lv001='{$lv001Esc}' LIMIT 1";
					$checkResult = db_query($checkSql);
					if (!$checkResult || mysqli_num_rows($checkResult) <= 0) {
						$vOutput = array('success' => false, 'message' => 'Không tìm thấy nhân viên trong ERP');
						break;
					}

					$vOutput = array(
						'success' => true,
						'employee_id' => $lv001,
						'image_token' => $tokenAnh,
						'affected_rows' => 0,
						'unchanged' => true,
						'table' => 'hr_lv0020',
						'column' => $cot,
					);
					break;
				}

				$vOutput = array(
					'success' => true,
					'employee_id' => $lv001,
					'image_token' => $tokenAnh,
					'affected_rows' => (int)$affectedRows,
					'unchanged' => false,
					'table' => 'hr_lv0020',
					'column' => $cot,
				);
				break;
		}
		break;

	case "getAnhTable":
		switch ($vfun) {
			case "getAnh":
				$lv001 = $input['lv001'] ?? $_POST['lv001'] ?? ($_GET['lv001'] ?? '');
				$cot = $input['cot'] ?? $_POST['cot'] ?? ($_GET['cot'] ?? '');
				$cot = trim((string)$cot);

				if (!preg_match('/^lv[0-9]{3}$/', $cot)) {
					http_response_code(400);
					echo "Invalid cot parameter.";
					exit();
				}

				if (!$lv001) {
					http_response_code(400);
					echo "Missing lv001 parameter.";
					exit();
				}

				$db = db_connect();
				if ($db === false) {
					http_response_code(500);
					echo "Loi ket noi den co so du lieu.";
					exit();
				}

				$lv001 = mysqli_real_escape_string($db, $lv001);
				$docsTable = function_exists('lv_docs_table_name') ? lv_docs_table_name('cr_lv0382') : '`cr_lv0382`';
				if ($docsTable === '') {
					http_response_code(500);
					echo "Cannot resolve documents table.";
					mysqli_close($db);
					exit();
				}

				$sql = "SELECT {$cot} FROM {$docsTable} WHERE lv002 = '$lv001'";
				$vresult = db_query($sql);

				if ($vresult && mysqli_num_rows($vresult) > 0) {
					$imageData = mysqli_fetch_assoc($vresult);
					$imageData = $imageData[$cot];

					header("Content-Type: image/jpeg");
					echo $imageData;
					mysqli_free_result($vresult);
					mysqli_close($db);
					exit();
				}

				http_response_code(404);
				echo "Image not found.";
				if ($vresult) {
					mysqli_free_result($vresult);
				}
				mysqli_close($db);
				exit();
		}
		break;
}

include("chamcong_ngocchung.php");
if ($vfun == 'data') {
	$i = 1;
	echo "[";
	foreach ($vOutput as $vData) {
		if ($i > 1)
			echo ",";
		echo json_encode($vData);

		$i++;
	}
	echo "]";
} else
	echo json_encode($vOutput);
